class Logger:
    def throw_error(self, msg: str) -> None:
        print(msg)

